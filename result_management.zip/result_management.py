import pandas as pd
import random
import json
import time
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, count, stddev, min, max
from kafka import KafkaProducer, KafkaConsumer
from pymongo import MongoClient
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import matplotlib.pyplot as plt
import seaborn as sns
from hdfs import InsecureClient

# Initialize Spark Session with Hadoop Integration
spark = SparkSession.builder.appName("ResultManagementSystem").config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000").getOrCreate()

# Initialize HDFS Client
hdfs_client = InsecureClient('http://localhost:9870', user='hadoop')

# Step 1: Generate Students' Profiles
num_students = 10000
students = [{'StudentID': i, 'Name': f'Student_{i}'} for i in range(1, num_students + 1)]
students_df = pd.DataFrame(students)

# Step 2: Generate Subjects
subjects = ['Electronics', 'Programming', 'Database', 'Data Science', 'Mathematics', 'DSA']

# Step 3: Generate Random Marks
for subject in subjects:
    students_df[subject] = [random.randint(30, 100) for _ in range(num_students)]

# Convert to Spark DataFrame
students_spark_df = spark.createDataFrame(students_df)

# Step 4: Compute Basic and Advanced Statistics
statistics_df = students_spark_df.select([avg(col(sub)).alias(f'{sub}_Average') for sub in subjects] +
                                         [stddev(col(sub)).alias(f'{sub}_StdDev') for sub in subjects] +
                                         [min(col(sub)).alias(f'{sub}_Min') for sub in subjects] +
                                         [max(col(sub)).alias(f'{sub}_Max') for sub in subjects])
statistics_df.show()

# Save statistics to HDFS as CSV
statistics_pandas_df = statistics_df.toPandas()
with hdfs_client.write('/user/hadoop/statistics.csv', encoding='utf-8') as writer:
    statistics_pandas_df.to_csv(writer, index=False)

# Step 5: Kafka Producer (Send statistics data)
producer = KafkaProducer(bootstrap_servers='localhost:9092', value_serializer=lambda v: json.dumps(v).encode('utf-8'))
data = statistics_df.toPandas().to_dict(orient='records')
producer.send('student_statistics', value=data)
producer.close()

# Step 6: Kafka Consumer (HoD receives data)
consumer = KafkaConsumer('student_statistics', bootstrap_servers='localhost:9092', value_deserializer=lambda x: json.loads(x.decode('utf-8')))
for message in consumer:
    print("Received Data:", message.value)
    break

# Step 7: Store Feedback in MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['ResultManagement']
feedback_collection = db['Feedback']
feedback_data = [{'StudentID': i, 'Feedback': random.choice(['Good', 'Bad', 'Excellent', 'Average', 'Poor'])} for i in range(1, num_students + 1)]
feedback_collection.insert_many(feedback_data)

# Step 8: Machine Learning Feedback Analysis
feedback_texts = [f['Feedback'] for f in feedback_data]
labels = [1 if fb in ['Good', 'Excellent'] else 0 for fb in feedback_texts]
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(feedback_texts)
clf = MultinomialNB()
clf.fit(X, labels)

# Step 9: Test Feedback Sentiment Analysis
new_feedback = ['Excellent Service']
X_new = vectorizer.transform(new_feedback)
prediction = clf.predict(X_new)
print("Feedback Sentiment:", "Positive" if prediction[0] == 1 else "Negative")

# Step 10: Store Final Results in NoSQL Database
results_collection = db['Results']
final_results = students_df.to_dict(orient='records')
results_collection.insert_many(final_results)

# Step 11: Visualizations
plt.figure(figsize=(10, 5))
sns.histplot(students_df['Mathematics'], kde=True, bins=20)
plt.title("Mathematics Marks Distribution")
plt.xlabel("Marks")
plt.ylabel("Frequency")
plt.savefig("math_distribution.png")
plt.show()

plt.figure(figsize=(10, 5))
sns.boxplot(data=students_df[subjects])
plt.title("Marks Distribution for All Subjects")
plt.savefig("subjects_boxplot.png")
plt.show()

# Step 12: Store Processed Data in HDFS
students_spark_df.write.csv("hdfs://localhost:9000/user/hadoop/students.csv", header=True, mode="overwrite")

# Step 13: Simulating Real-Time Data Processing
for i in range(10):
    print(f"Processing batch {i+1}...")
    time.sleep(1)

print("Result Management System Execution Completed!")
